#!/usr/bin/env python

import filecmp
import os.path

def check_files(fnames):
    """
    Check the files one by one.
    """
    flag = True

    for fname in fnames:
        exp_fname = "".join(["exp_", fname])
        if not filecmp.cmp(fname, exp_fname):
            # these two files are different
            print "file: ", fname, "is different from ", exp_fname
            print "Check the r2s code!"
            flag = False
            break
        else:
            print "file: ", fname, "passed the test"
    return flag


def check_files_exist(fnames):
    """
    Check the existence of output files of r2s step1 or step2.
    If the defined files are all exist, return True.
    If not any defined files is exist, return False.
    If some of the defined files exist, some not exist, report Error.
    """
    exist_no = 0  
    for fname in fnames:
        exist_no += os.path.isfile(fname)
    if exist_no == len(fnames):
        return True
    elif exist_no == 0:
        return False
    else:
        raise RuntimeError("Some output files not exist! Check the code!")
    

if __name__ == "__main__":
    # define the files need to check
    output_files_1 = {"alara_fluxin",
                      "alara_inp",
                      "alara_matlib"}
    output_files_2 = {"e_bounds",
                      "total_photon_source_intensities.txt"}

    flag1, flag2 = True, True
    # check the output files of r2s step1
    if check_files_exist(output_files_1):
        flag1 = check_files(output_files_1)
    # check the output files of r2s step2
    if check_files_exist(output_files_2):
        flag2 = check_files(output_files_2)
    # overall                 
    if flag1 and flag2:
        print "No error found, R2S test passed!"
    elif not flag1 and not flag2:
        print "No need to check!"
    else:
        print "R2S test not passed!"

